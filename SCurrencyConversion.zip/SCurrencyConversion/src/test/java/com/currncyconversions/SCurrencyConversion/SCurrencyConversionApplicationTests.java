package com.currncyconversions.SCurrencyConversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SCurrencyConversionApplicationTests {

	@Test
	void contextLoads() {
	}

}
